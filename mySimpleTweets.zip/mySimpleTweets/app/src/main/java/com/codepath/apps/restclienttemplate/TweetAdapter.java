package com.codepath.apps.restclienttemplate;

public class TweetAdapter {
    // pass in the tweets array in the constructor

    // for each row, inflate the layout and cache references into Viewholder

    // bind the values based on the position of the element

    // create ViewHolder class

    public static class ViewHolder extends RecyclerView. {

    }
}
